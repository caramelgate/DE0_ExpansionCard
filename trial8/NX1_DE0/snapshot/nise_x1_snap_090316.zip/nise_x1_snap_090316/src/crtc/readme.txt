CRTC6845(HD46505) CORE beta1 from FPGA Rock'ola

http://office-dsan.hp.infoseek.co.jp/rockola/fpga_rockola.htm
